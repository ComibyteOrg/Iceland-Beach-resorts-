<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="../static/styles/style.css">
    <link rel="stylesheet" href="style.css">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
   <link rel="stylesheet" href="../static/CAOS.file/CAOS.file.v-1.5/style.css">
   <link rel="stylesheet" href="../bootstrap-5.3.2-dist/css/bootstrap.min.css">
    <title>Iceland Beach resorts | Admin Pannel</title>
</head>
<body>

<?php  
    if(isset($_GET['room']) and $_GET['room'] != ""):
        $room = $_GET['room'];
?>

    <div class="container p-4">
        <form method="post" class="mt-5 mx-auto" style="width: 500px; max-width: 90%;">
            <h2>Add new room to room "<?php echo $room;?>"</h2>
            <div class="mb-1">
                <label for="r_name" class="form-label">Recipient Name</label>
                <input type="text" class="form-control" id="r_name" name="r_name" required>
            </div>
            <div class="mb-1">
                <label for="r_mail" class="form-label">Recipient Email</label>
                <input type="text" class="form-control" id="r_mail" name="r_mail" required>
            </div>
            <div class="mb-1">
                <label for="signin" class="form-label">Signin Date</label>
                <input type="text" class="form-control" id="signin" name="signin" required>
            </div>
            <div class="mb-1">
                <label for="signout" class="form-label">Signout Date</label>
                <input type="text" class="form-control" id="signout" name="signout" required>
            </div>
            <div class="mt-3">
                <a href="index.php" class="btn btn-close-white btn-secondary">Back Home</a>
                <button type="submit" class="btn btn-success" name="booknow">Book Room</button>
            </div>
        </form>
    </div>


<?php 
    elseif(isset($_GET['free']) and $_GET['free']!= NULL): 
    $room = $_GET['free'];
?>

    <div class="container p-4">
        <form method="post" class="mt-5 mx-auto" style="width: 500px; max-width: 90%;">
        <h2>Free room "<?php echo $room;?>"</h2>
            <p>Are You sure you want to free this room. Note: The if room is free any user can book this room and can see it on the booking section</p>
            <div class="mt-3">
                <a href="index.php" class="btn btn-close-white btn-secondary">Back Home</a>
                <button type="submit" class="btn btn-success" name="unfree">Free Room</button>
            </div>
        </form>
    </div>
<?php else: ?>
    <div class="mt-5 mx-auto text-center" style="width: 500px; max-width: 90%;">
        <p class="text-center lead"> No room is selected </p>
        <a href="index.php" class="btn btn-close-white btn-secondary">Back Home</a>
    </div>
<?php endif;?>






<!-- FOOTER -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="../bootstrap-5.3.2-dist/js/bootstrap.bundle.js"></script>
<!-- javascript -->
<script src="../static/scripts/script.js"></script>
</body>
</html>