<?php 
    session_start();
    require_once "../validations/Validatemember.php";

    if(isset($_GET['type']) or $_GET['type'] !== NULL){
        $mtype = $_GET['type'];
        if($mtype == "basic"){
            $price = 20000;
            $type = "basic";
        }elseif($mtype == "premium"){
            $price = 50000;
            $type = "premium";
        }else{
            header("Location: ../../membership");
        }
    }else{
        header("Location: ../../membership");
    }

    if(isset($_POST['proceed'])){
        $memberbook = new Validatemember();
        $alerts = $memberbook->validate($_POST, $price);
        $_SESSION['type'] = $type;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="../../static/styles/style.css">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
   <link rel="stylesheet" href="../../static/CAOS.file/CAOS.file.v-1.5/style.css">
   <link rel="stylesheet" href="../../bootstrap-5.3.2-dist/css/bootstrap.min.css">
   <link rel="icon" type="image/png" sizes="16x16" href="../../static/images/img (1).png">
    <title>Iceland Beach resorts | Join Membership</title>
</head>
<body>

    <style>
        form{
            width: 500px;
            max-width: 90%;
        }
    </style>


    <div class="container my-5 py-5">
        <form method="post" class="mx-auto">
            <h3 class="text-uppercase">REGISTER AS A <?=$type?> MEMBER</h3>
            <?php require_once "../controller/alert.php"; ?>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="floatingInput" placeholder="name example" name="fullname">
                <label for="floatingInput">Full Name</label>
            </div>
            <div class="form-floating mb-3">
                <input type="email" class="form-control" id="floatingInput2" placeholder="name@example.com" name="email">
                <label for="floatingInput2">Email Address</label>
            </div>
            <div class="form-floating mb-3">
                <input type="password" class="form-control" id="floatingInput3" placeholder="name@example.com" name="password">
                <label for="floatingInput3">Password</label>
            </div>
            <div class="form-floating mb-3">
                <select name="duration">
                    <option selected disabled>Duration</option>
                    <option value="1">Montly</option>
                    <option value="6">Quarterly</option>
                    <option value="12">Yearly</option>
                </select>
            </div>
            <div class="form-group mb-3">
                <input type="checkbox" id="terms" name="terms">
                <label for="terms">I agree to the terms and condition</label>
            </div>
            <div class="form-group mb-3">
                <button type="submit" name="proceed" class="btn btn-warning w-100">Proceed</button>
            </div>
            <div class="form-group mb-3">
                <a href="../../index" class="btn btn-secondary w-100">Back Home</a>
            </div>
        </form>
    </div>











<!-- FOOTER -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="../../bootstrap-5.3.2-dist/js/bootstrap.bundle.js"></script>
<!-- javascript -->
<script src="../../static/scripts/script.js"></script>
</body>
</html>