<?php 
    session_start();
    if(!isset($_SESSION['cart'])){
        header("Location: ../../services");
        $_SESSION['cart'] = [];
        $total = 0;
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Form</title>
    <style>
                /* Form Styling */
        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 1em;
            background: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form input, form select, form textarea {
            width: 100%;
            padding: 0.5em;
            margin-bottom: 1em;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        form input:focus, form select:focus, form textarea:focus {
            border-color: #007bff;
            outline: none;
        }

        form button, form a{
            padding: 0.7em ;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
        }

        form button:hover, form a:hover{
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <form  method="post">
        <h2>Checkout Form</h2>
        <?php 
            if(isset($_SESSION['cart'])){
                $total = $_SESSION['total_cart'];
                $product_id = $_SESSION['product_id'];
                $item['quantity'] = $_SESSION['quantity'];
                foreach ($_SESSION['cart'] as $product_id => $item) {
                    echo "<p>" . $item['name'] . " - ₦" . $item['price'] . " (Quantity: " . $item['quantity'] . ")</p>";
                }
            }else{
                $total = 0;
            }
            echo "<h1>$total</h1>";
        ?>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="signin">Signin date:</label>
        <input type="datetime-local" id="signin" name="signin" required><br><br>
        
        <button type="submit" name="proceed"> Proceed </button>
        <a class="back home" href="../../services.php">Back Home</a>
    </form>
</body>
</html>

<?php 
    if(isset($_POST['proceed'])){
        $email = htmlspecialchars($_POST['email']);
        $amount = htmlspecialchars($total);

        $_SESSION['fullname'] = $_POST['name'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['signin'] = $_POST['signin'];
        $enddate = clone new DateTime($_POST['signin']);
        $_SESSION['signout'] = $enddate->modify('+1 day');
    
            //* Prepare our rave request
            $request = [
            'tx_ref' => "ice".time(),
            'amount' => $amount,
            'currency' => 'NGN',
            'payment_options' => 'card',
            'redirect_url' => 'http://localhost/iceland/core/processor/processservice.php',
            'customer' => [
                'email' => $email,
                'name' => htmlspecialchars($_POST['name'])
            ],
            'meta' => [
                'price' => $amount
            ],
            'customizations' => [
                'title' => 'Paying for Iceland Service',
                'description' => 'Iceland services checkout'
            ]
        ];
    
        //* Ca;; f;iterwave emdpoint
        $curl = curl_init();
    
        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.flutterwave.com/v3/payments',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($request),
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer FLWSECK_TEST-4d6bed9cf2ad2b68f237f437cf29b591-X',
            'Content-Type: application/json'
        ),
        ));
    
        $response = curl_exec($curl);
    
        curl_close($curl);
        
        $res = json_decode($response);
        if($res->status == 'success')
        {
            $link = $res->data->link;
            header('Location: '.$link);
        }
        else
        {
            echo "<div style='text-align:center;'>We can not process your payment {$res->status}</div>";
        }
    }
?>