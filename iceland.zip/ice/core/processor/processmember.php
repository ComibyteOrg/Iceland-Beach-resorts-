<?php 
    require_once "../config/dbquery.php";
    require_once "../controller/sendmail.php";
    session_start();

    $query = new Dbquery();
    $mail = new Sendmail();

    if(isset($_GET['status']))
    {
        //* check payment status
        if($_GET['status'] == 'cancelled')
        {
            // echo 'YOu cancel the payment';
            header('Location: http://localhost/iceland/membership');
        }
        elseif($_GET['status'] == 'successful')
        {
            $txid = $_GET['transaction_id'];

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.flutterwave.com/v3/transactions/{$txid}/verify",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                  "Content-Type: application/json",
                  "Authorization: Bearer FLWSECK_TEST-4d6bed9cf2ad2b68f237f437cf29b591-X"
                ),
              ));
              
              $response = curl_exec($curl);
              
              curl_close($curl);
               
              $res = json_decode($response);
              if($res->status)
              {
                $amountPaid = $res->data->charged_amount;
                $amountToPay = $res->data->meta->price;
                $customers_name = $res->data->customer->name;
                $customers_mail = $res->data->customer->email;

                $start_date = date("Y-m-d H:i:s");
                $validity = (int)$_SESSION['duration'] * 30;
                $expiry_date = date("Y-m-d H:i:s", strtotime($start_date. "+ $validity days"));

                $member_query = $query->insert("membership", ['full_name' => $_SESSION['fullname'], 'email' => $_SESSION['email'], 'password' => $_SESSION['password'], 'type' => $_SESSION['type'], 'start_date' => $start_date, 'end_date' => $expiry_date, 'member_status' => 'paid', 'price' => $_SESSION['price'], 'total' => $_SESSION['normal_price'], 'mailsent' => NULL]);

                $u_message = 
                "
                    <h1>Thank You for purchasing your {$_SESSION['type']} membership at Iceland Beach</h1>
                    <p>You have successfully purchased your {$_SESSION['type']} membership at Iceland Beach, You now have access to all cool features of iceland beach</p>
                    <a href='https://icelandbeach.com' class='cta-button'>Visit Website</a>
                ";

                $u_format = $mail->message($u_message);

                $a_message = 
                "
                    <h1>New Iceland membership purchase</h1>
                    <p>We have A new membership purchase from {$customers_name},{$customers_mail}, Valid for {$validity} days. The payment have been successfully confirmed.</p>
                ";

                $a_format = $mail->message($a_message);

                if($member_query){
                    if($amountPaid >= $amountToPay) {
                        $send_mail = $mail->mailsender("", $a_format, $u_format, $_SESSION['email']);
                        if($send_mail){
                            header("Location: http://localhost/iceland/core/processor/success2.php");
                        }

                    }else{
                        echo 'Fraud transaction detected';
                    }
                }else{
                    echo 'User Not Found';
                }

              }
              else
              {
                  echo 'Can not process payment';
              }
        }
    }
?>