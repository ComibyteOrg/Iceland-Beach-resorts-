<?php 
    require_once "../config/dbquery.php";
    require_once "../controller/sendmail.php";

    $query = new Dbquery();
    $mail = new Sendmail();

    if(isset($_GET['status']))
    {
        //* check payment status
        if($_GET['status'] == 'cancelled')
        {
            // echo 'YOu cancel the payment';
            header('Location: http://localhost/iceland/rooms');
        }
        elseif($_GET['status'] == 'successful')
        {
            $txid = $_GET['transaction_id'];

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.flutterwave.com/v3/transactions/{$txid}/verify",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                  "Content-Type: application/json",
                  "Authorization: Bearer FLWSECK_TEST-4d6bed9cf2ad2b68f237f437cf29b591-X"
                ),
              ));
              
              $response = curl_exec($curl);
              
              curl_close($curl);
               
              $res = json_decode($response);
              if($res->status)
              {
                $amountPaid = $res->data->charged_amount;
                $amountToPay = $res->data->meta->price;
                $customers_name = $res->data->customer->name;
                $customers_mail = $res->data->customer->email;

                $room_query = $query->update("room", ['is_booked' => 'booked', 'mailsent' => NULL], "customer_name = '$customers_name' AND is_booked = 'no'");

                $room_select = $query->select("room", "*", "email = ?", [$customers_mail], "s");
                if($room_select->num_rows == 1){
                    $selected = $room_select->fetch_assoc();
                }else{
                    echo "You have booked a room already, Please choose another mail tobook another room";
                }

                $u_message = 
                "
                    <h1>Thank You for booking a room from Iceland Beach</h1>
                    <p>You have successfully Booked a room from Iceland Beach, And your room has been reserved for you. Contact us if you have more questions about iceland room booking</p>
                    <a href='https://icelandbeach.com' class='cta-button'>Visit Website</a>
                ";

                $u_format = $mail->message($u_message);

                $signin = new DateTime($selected['start_date ']);
                $signout = new DateTime($selected['end_date ']);
    
                $interval = $signin->diff($signout);
                $days = $interval->days;

                $a_message = 
                "
                    <h1>New Iceland Room Booked</h1>
                    <p>A room has just been booked by a user {$customers_name}, Room name {$selected['room_name']} from the {$selected['room_category']} Category on For {$days} days.</p><br>
                    <h4>Room Price : {$selected['room_price']}</h4>
                    <h2>Paid Price : {$selected['total_price']}</h2>
                ";

                $a_format = $mail->message($a_message);

                if($room_query){
                    if($amountPaid >= $amountToPay) {
                        $send_mail = $mail->mailsender("", $a_format, $u_format, $selected['email']);
                        if($send_mail){
                            header("Location: http://localhost/iceland/core/processor/success.php");
                        }

                    }else{
                        echo 'Fraud transaction detected';
                    }
                }else{
                    echo 'User Not Found';
                }

              }
              else
              {
                  echo 'Can not process payment';
              }
        }
    }
?>