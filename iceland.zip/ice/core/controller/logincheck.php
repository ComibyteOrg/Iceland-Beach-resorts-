<?php 
    require_once "core/config/dbquery.php";
    if(isset($_SESSION['email'])){
        $users = new Dbquery();
        $email = $_SESSION['email'];
        $selectuser = $users->select("membership", "*", "email = ?", [$email], "s");
        $user = $selectuser->fetch_assoc(); 
    }