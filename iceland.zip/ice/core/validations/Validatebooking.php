<?php
    require_once "core/config/dbquery.php";
    require_once "core/controller/controller.php";
    class Validatebooking extends Dbquery{
        public $alerts = array();
        public function validate($post){
            $fullname = Controller::sanitize($post['fullname']);
            $email = Controller::sanitize($post['email']);
            $roomname = Controller::sanitize($post['roomname']);
            $signindate = Controller::sanitize($post['signindate']);
            $signoutdate = Controller::sanitize($post['signoutdate']);
            $roomprice = Controller::sanitize($post['roomprice']);

            if(empty($fullname) or empty($email)){
                $this->alerts[] = Controller::alert("danger", "All field must be filled");
            }

            if(isset($_GET['room'])){
                $room_name = $_GET['room'];
            }
            // calculating date and time with the fee 
            $signin = new DateTime($signindate);
            $signout = new DateTime($signoutdate);

            $interval = $signin->diff($signout);
            $days = $interval->days;
            $total_fee = $days * $roomprice;
            $current_date = new DateTime();

            if($signin < $current_date or $signout < $current_date and $signin !== $current_date or $signout < $signin){
                $this->alerts[] = Controller::alert("danger", 'Please choose a valid Date');
            }

            // $select_mail = $this->select("room", "email", "email = ?", [$email], "s");
            // if($select_mail->num_rows == 1){
            //     $this->alerts[] = Controller::alert("danger", 'Mail have been used to book, Please choose a diffrent mail');
            // }

            if(count($this->alerts) == 0){
                $update_room = $this->update("room", ['customer_name' => $fullname,'email' => $email, 'start_date' => $signindate, 'end_date' => $signoutdate, 'total_price' => $total_fee], "room_name = '$room_name'");

                if($update_room){
                    $this->alerts[] = Controller::alert("success", "Order added to queue");
                    echo Controller::counttime("1", "core/processor/roompayment.php?room=$room_name");
                }else{
                    $this->alerts[] = Controller::alert("warning", "Cannot process Order {$this->conn->error}");
                }
            }

            return $this->alerts;
        }
    }